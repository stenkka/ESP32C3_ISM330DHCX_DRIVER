# `gpsutils` GPS Utilities

The `gpsutils` directory is used to include libraries from external projects
that are not part of NuttX Applications, but are useful for NuttX developers and
users.

## `minmea` GPS NMEA 0183 parser

MINMEA is a NMEA parser developed by Kosma Moczek. Kosma is also a NuttX
contributor.
