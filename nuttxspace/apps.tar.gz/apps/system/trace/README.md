System / `trace` Task Tracer
============================

See https://nuttx.apache.org/docs/latest/guides/tasktraceuser.html
